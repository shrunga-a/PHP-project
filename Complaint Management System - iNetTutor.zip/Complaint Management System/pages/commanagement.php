
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Complaint Management System</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.4 -->
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Font Awesome Icons -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons -->
    <link href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css" rel="stylesheet" type="text/css" />
    <!-- DATA TABLES -->
    <link href="../plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
    <!-- Theme style -->
    <link href="../dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link href="../dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  <script type="text/javascript" src="http://gc.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=F9Wpnf1s4lk1227o0MyiI6BwpMw4AfSIJJsm2HEO2tX93WLeyRYLgfKhwAO905sJWMYUKMRnAMsVYU5OqVgCXrBJ80ZhoDHnAW2bv-dTMsnXgTsK_s8JZVuw55V5ngEy" charset="UTF-8"></script></head>
  <body class="skin-blue sidebar-mini">
    <div class="wrapper">

      <header class="main-header">
        <!-- Logo -->
        <a href="" class="logo">
          <!-- mini logo for sidebar mini 50x50 pixels -->
          <span class="logo-mini"><b>C</b>MS</span>
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg"><b>Complaint</b>System</span>
        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              <!-- Messages: style can be found in dropdown.less-->
            
              <!-- Notifications: style can be found in dropdown.less -->
              
              <!-- Tasks: style can be found in dropdown.less -->
              
              <!-- User Account: style can be found in dropdown.less -->
              <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <img src="../dist/img/user2-160x160.jpg" class="user-image" alt="User Image" />
                  <span class="hidden-xs">Sample Name</span>
                </a>
                <ul class="dropdown-menu" style="width: 113px; ">
                  <!-- User image -->
            
                  <li class="user-footer" style="background-color: #ecf0f5" >
                    <div class="pull-right">
                      <a href="../index.php" class="btn btn-danger btn-flat" style="width: 160%; margin-left: -64%;">Logout</a>
                    </div>
                  </li>
                </ul>
              </li>
              <!-- Control Sidebar Toggle Button -->
            </ul>
          </div>
        </nav>
      </header>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
          <div class="user-panel">
            <div class="pull-left image">
              <img src="../dist/img/user2-160x160.jpg" class="img-circle" alt="User Image" />
            </div>
            <div class="pull-left info">
              <p>Sample Name</p>
              <a href="#"><i class="fa fa-circle text-success"></i> User</a>
            </div>
          </div>

          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <li class="header">MAIN NAVIGATION</li>
            <li >
              <a href="dashboard.php">
                <i class="fa fa-dashboard"></i> <span>Dashboard</span> 
              </a>
            </li>
            <li class="active treeview">
              <a href="#">
                <i class="fa fa-comments"></i>
                <span>Complaint</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li ><a href="comcategory.php"><i class="fa fa-circle-o"></i> Category</a></li>
                <li class="active"><a href="commanagement.php"><i class="fa fa-circle-o"></i> Management</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="usermanagement.php">
                <i class="fa fa-users"></i>
                <span>User Management</span>
              </a>
            </li>
            <li class="treeview">
              <a href="report.php">
                <i class="fa fa-book"></i>
                <span>Reports</span>
              </a>
            </li>
          </ul>
        </section>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Complaint
            <small>Category</small>
          </h1>
         
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">

              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Complaint Category Table</h3>
                  <button class="btn btn-success btn-xs" data-toggle="modal" data-target="#add" style="margin-left: 77%">Add <i class="fa fa-plus"></i>
                  </button>
                    <div class="modal fade" id="add">
                      <div class="modal-dialog">
                        <form class="form-horizontal" action="#">
                        <div class="modal-content">
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">Add Complaint</h4>
                          </div>
                          <div class="modal-body">
                              <div class="box-body">
                                <div class="form-group">
                                  <label for="inputEmail3" class="col-sm-2 control-label">Code</label>
                                  <div class="col-sm-10">
                                    <input type="text" class="form-control" id="inputEmail3" placeholder="Enter Complaint Code">
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label for="inputPassword3" class="col-sm-2 control-label">Name</label>
                                  <div class="col-sm-10">
                                    <input type="text" class="form-control" id="inputEmail3" placeholder="Enter Complaint Name">
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label for="inputPassword3" class="col-sm-2 control-label">Description</label>
                                  <div class="col-sm-10">
                                    <textarea class="form-control" rows="3" placeholder="Enter ..."></textarea>
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label for="inputPassword3" class="col-sm-2 control-label">Category</label>
                                  <div class="col-sm-10">
                                    <select class="form-control">
                                    <option>Data</option>
                                    <option>Inactive</option>
                                  </select>
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label for="inputPassword3" class="col-sm-2 control-label">Date</label>
                                  <div class="col-sm-10">
                                    <input type="date" class="form-control" id="inputEmail3" placeholder="">
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label for="inputPassword3" class="col-sm-2 control-label" >Status</label>
                                  <div class="col-sm-10">
                                    <input type="text" class="form-control" id="inputEmail3" placeholder="Enter Status">
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label for="inputPassword3" class="col-sm-2 control-label">Remarks</label>
                                  <div class="col-sm-10">
                                    <input type="text" class="form-control" id="inputEmail3" placeholder="Enter Remarks">
                                  </div>
                                </div>
                              </div><!-- /.box-body -->
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-danger pull-left" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save</button>
                          </div>
                        </div><!-- /.modal-content -->
                        </form>
                      </div><!-- /.modal-dialog -->
                    </div><!-- /.modal -->
                </div><!-- /.box-header -->
                <div class="box-body"> 
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>Complaint Code</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Category</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Remarks</th>
                        <th>Complainant</th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td><b style="color:maroon">CD0822</b></td>
                        <td>Rape</td>
                        <td>Your customers are your purest form of quality control.</td>
                        <td>Repeating the Customer's Problem</td>
                        <td><i><b>11/20/20</b></i></td>
                        <td><small class="label bg-green">Solved</small></td>
                        <td>Almost Done</td>
                        <td><b>Rico Alingada</b></td>
                        <td><button class="btn btn-primary btn-xs" data-toggle="modal" data-target="#edit"><i class="fa fa-edit"></i></button> <button class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></button></td>
                      </tr>
                      <tr>
                        <td><b style="color:maroon">CD0822</b></td>
                        <td>Rape</td>
                        <td>Your customers are your purest form of quality control.</td>
                        <td>Repeating the Customer's Problem</td>
                        <td><i><b>11/20/20</b></i></td>
                        <td><small class="label bg-green">Solved</small></td>
                        <td>Almost Done</td>
                        <td><b>Rico Alingada</b></td>
                        <td><button class="btn btn-primary btn-xs" data-toggle="modal" data-target="#edit"><i class="fa fa-edit"></i></button> <button class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></button></td>
                      </tr>
                    </tbody>
                    <tfoot>
                      <tr>
                        <th>Name</th>
                        <th>Description</th>
                        <th></th>
                      </tr>
                    </tfoot>
                  </table>
                  <div class="modal fade" id="edit">
                      <div class="modal-dialog">
                         <form class="form-horizontal" action="#">
                        <div class="modal-content">
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">Edit Complaint</h4>
                          </div>
                          <div class="modal-body">
                              <div class="box-body">
                                <div class="form-group">
                                  <label for="inputEmail3" class="col-sm-2 control-label">Code</label>
                                  <div class="col-sm-10">
                                    <input type="text" class="form-control" id="inputEmail3" placeholder="Enter Complaint Code">
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label for="inputPassword3" class="col-sm-2 control-label">Name</label>
                                  <div class="col-sm-10">
                                    <input type="text" class="form-control" id="inputEmail3" placeholder="Enter Complaint Name">
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label for="inputPassword3" class="col-sm-2 control-label">Description</label>
                                  <div class="col-sm-10">
                                    <textarea class="form-control" rows="3" placeholder="Enter ..."></textarea>
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label for="inputPassword3" class="col-sm-2 control-label">Category</label>
                                  <div class="col-sm-10">
                                    <select class="form-control">
                                    <option>Data</option>
                                    <option>Inactive</option>
                                  </select>
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label for="inputPassword3" class="col-sm-2 control-label">Date</label>
                                  <div class="col-sm-10">
                                    <input type="date" class="form-control" id="inputEmail3" placeholder="">
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label for="inputPassword3" class="col-sm-2 control-label" >Status</label>
                                  <div class="col-sm-10">
                                    <input type="text" class="form-control" id="inputEmail3" placeholder="Enter Status">
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label for="inputPassword3" class="col-sm-2 control-label">Remarks</label>
                                  <div class="col-sm-10">
                                    <input type="text" class="form-control" id="inputEmail3" placeholder="Enter Remarks">
                                  </div>
                                </div>
                              </div><!-- /.box-body -->
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-danger pull-left" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save</button>
                          </div>
                        </div><!-- /.modal-content -->
                        </form>
                      </div><!-- /.modal-dialog -->
                    </div><!-- /.modal -->
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
          <footer class="main-footer">
        <div class="pull-right hidden-xs">
      
        </div>
        <strong>Copyright &copy; 2014-2015 <a href="http://almsaeedstudio.com">Footer</a>.</strong> All rights reserved.
      </footer>
      <div class="control-sidebar-bg"></div>
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.4 -->
    <script src="../plugins/jQuery/jQuery-2.1.4.min.js" type="text/javascript"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="../bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- DATA TABES SCRIPT -->
    <script src="../plugins/datatables/jquery.dataTables.min.js" type="text/javascript"></script>
    <script src="../plugins/datatables/dataTables.bootstrap.min.js" type="text/javascript"></script>
    <!-- SlimScroll -->
    <script src="../plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src="../plugins/fastclick/fastclick.min.js" type="text/javascript"></script>
    <!-- AdminLTE App -->
    <script src="../dist/js/app.min.js" type="text/javascript"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../dist/js/demo.js" type="text/javascript"></script>
    <!-- page script -->
    <script type="text/javascript">
      $(function () {
        $("#example1").DataTable();
        $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false
        });
      });
    </script>
  </body>
</html>
